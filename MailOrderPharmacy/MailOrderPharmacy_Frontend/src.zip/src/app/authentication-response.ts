export interface AuthenticationResponse {
    userid:string,
    name:string,
    valid:boolean
}